angular.module('persistentOLXApp', ['ui.router', 'ngSanitize', 'searchBox', 'productDetails', 'sellerInformation', 'productDescription', 'productSpecifications', 'ngAnimate', 'ui.bootstrap', 'captchaImagePuzzle', 'countDown'])
    .config(function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/login');
        $stateProvider
            .state('login', {
                url: '/login',
                templateUrl:'templates/login.html',
                controller: 'loginController'
            })
            .state('productCatalogue', {
                url: '/productCatalogue',
                templateUrl:'templates/productCatalogue.html',
                controller: 'productCatalogueController'
            })
            .state('cart', {
                url: '/cart',
                templateUrl:'templates/cart.html',
                controller: 'cartController'
            })
            .state('checkOut', {
                url: '/checkOut',
                templateUrl:'templates/checkOut.html',
                controller: 'checkOutController'
            })
            .state('purchaseSummary', {
                url: '/purchaseSummary',
                templateUrl:'templates/purchaseSummary.html',
                controller: 'purchaseSummaryController'
            })
            .state('home', {
                url: '/home',
                controller: 'productDetailsController'
            })
            .state('productDetails', {
                url: '/productDetails',
                templateUrl: 'templates/productDetails.html',
                controller: 'productDetailsController'
            })
            .state('sellerInformation', {
                url: '/sellerInformation',
                templateUrl: 'templates/sellerInformation.html',
                controller: 'sellerInformationController'
            });
    }).run(function ($rootScope, $state, $stateParams) {
    $rootScope.$state = $state;
    $rootScope.$stateParams = $stateParams;
});
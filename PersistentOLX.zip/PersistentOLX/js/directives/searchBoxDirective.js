angular.module('searchBox', [])
    .directive('searchBox', function (persistentOLXFactory, $state) {
        return {
            restrict: 'E',
            templateUrl: 'templates/searchBox.html',
            link: function ($scope, element, attr) {
                persistentOLXFactory.fetchPhonesList(attr.dropdownlisturl).then(function (data, status, headers, config) {
                    $scope.phones = data;
                }, function (data, status) {
                    console.error('Error in fetching phones list' + data + status)
                });

                $scope.onSearchItemClick = function (phoneID, name) {
                    $scope.query = name;
                    persistentOLXFactory.fetchSearchItemDetails(phoneID).then(function (data) {}, function (data) {
                        console.log("Error occured while fetching product details")
                    });
                    $state.go('productDetails');
                    $scope.searchBoxDropDownList = false;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                };
                $scope.onSearchFieldFocus = function () {
                    $scope.searchBoxDropDownList = true;
                }
            }
        }
    });
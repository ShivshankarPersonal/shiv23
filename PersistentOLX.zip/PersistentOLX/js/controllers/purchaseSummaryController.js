angular.module("persistentOLXApp")
    .controller("purchaseSummaryController", function ($scope, $state, persistentOLXFactory, $rootScope, $location, $timeout) {
        $scope.address = persistentOLXFactory.address;

    });
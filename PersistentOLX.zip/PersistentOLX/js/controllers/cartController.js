angular.module("persistentOLXApp")
    .controller("cartController", function ($scope, $state, persistentOLXFactory, $rootScope, $location, $timeout) {
        var length = persistentOLXFactory.cartContent.length;
        $scope.cartItems = [];
        for(var i = 0; i < length; i++){
            persistentOLXFactory.selectedItem = persistentOLXFactory.cartContent[i];
            persistentOLXFactory.fetchSearchItemDetails().then(function (data) {
                $scope.cartItems.push(angular.copy(data));
                persistentOLXFactory.cartItems = $scope.cartItems;
            }, function () {
                console.error("Unable to fetch Item details")
            })
        }
        
        // $scope.checkOut = function () {
        // }
    });

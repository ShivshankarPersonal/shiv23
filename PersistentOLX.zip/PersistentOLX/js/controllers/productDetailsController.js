angular.module('persistentOLXApp')
    .controller('productDetailsController', function ($scope, $state, persistentOLXFactory, $rootScope) {
        // if (Object.keys(persistentOLXFactory.itemDetails).length === 0 && persistentOLXFactory.itemDetails.constructor === Object ) {
            persistentOLXFactory.fetchSearchItemDetails().then(function (data) {
                $scope.data = data;
                bindDataToView()
            }, function (data) {
                console.error("Unabel to Fetch items Details")
            });
        // }
        // else {
        //     $scope.data = persistentOLXFactory.itemDetails;
        //     bindDataToView()
        // }
        // var data = $scope.data;
        function bindDataToView() {
            $scope.name = $scope.data.name;
            $scope.description = $scope.data.description;
            $scope.images = $scope.data.images;
            $scope.additionalFeatures = $scope.data.additionalFeatures;
            $scope.android = $scope.data.android;
            $scope.availability = $scope.data.availability;
            $scope.battery = $scope.data.battery;
            $scope.camera = $scope.data.camera;
            $scope.connectivity = $scope.data.connectivity;
            $scope.display = $scope.data.display;
            $scope.hardware = $scope.data.hardware;
            $scope.id = $scope.data.id;
            $scope.sizeAndWeight = $scope.data.sizeAndWeight;
            $scope.storage = $scope.data.storage;
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        }
        
        $scope.addToCart = function (id) {
            persistentOLXFactory.cartContent.push(id);
            $state.go('cart');
        }

    });

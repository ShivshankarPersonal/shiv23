angular.module("persistentOLXApp")
    .controller("productCatalogueController", function ($scope, $state, persistentOLXFactory, $rootScope, $location, $timeout) {
        $scope.max = 5;
        $scope.rate = 3;
        $scope.starts = [1,2,3,4,5]
        $scope.brands = ['a','b']

        $scope.onListItemClick = function (itemID) {
            persistentOLXFactory.selectedItem = itemID;
           $state.go('productDetails')
        }

        function onlyUnique(value, index, self) {
            return self.indexOf(value) === index;
        }


        var a = ['a', 1, 1, 2,'a', 2, '1'];
        $scope.brands = a.filter( onlyUnique );
        persistentOLXFactory.fetchPhonesList('phones').then(function (data) {
            $scope.items = data;
        },function (data) {
            console.error("Unable to Fetch Product Catalogue list")
        });
    });
angular.module("persistentOLXApp")
    .controller("checkOutController", function ($scope, $state, persistentOLXFactory, $rootScope, $location, $timeout) {
        $scope.onSubmit = function () {
            persistentOLXFactory.address.name = $scope.name;
            persistentOLXFactory.address.email = $scope.email;
            persistentOLXFactory.address.mobile = $scope.mobile;
            persistentOLXFactory.address.address = $scope.address;

        }
    });